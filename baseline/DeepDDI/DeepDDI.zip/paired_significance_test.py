# -*- coding: utf-8 -*-
"""
Paired significance tests on repeated seed-fold results.
Input files must have dataset, method, seed, fold and metric columns.
Use the same 15 split ids for both methods.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import ttest_rel, wilcoxon


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metrics_csv", required=True, help="Concatenated metrics from all methods")
    ap.add_argument("--method_a", required=True, help="Usually your method, e.g. RA-DDI")
    ap.add_argument("--method_b", required=True, help="Baseline method, e.g. DeepDDI_shared")
    ap.add_argument("--metric", default="f1_macro")
    ap.add_argument("--dataset", default=None, help="Optional dataset filter")
    ap.add_argument("--out_csv", required=True)
    args = ap.parse_args()

    df = pd.read_csv(args.metrics_csv)
    if args.dataset:
        df = df[df["dataset"].astype(str) == str(args.dataset)]
    needed = {"dataset", "method", "seed", "fold", args.metric}
    miss = needed - set(df.columns)
    if miss:
        raise SystemExit(f"Missing columns {miss} in {args.metrics_csv}")

    rows = []
    for dataset, gd in df.groupby("dataset"):
        a = gd[gd["method"] == args.method_a][["seed", "fold", args.metric]].rename(columns={args.metric: "a"})
        b = gd[gd["method"] == args.method_b][["seed", "fold", args.metric]].rename(columns={args.metric: "b"})
        m = a.merge(b, on=["seed", "fold"], how="inner").dropna()
        if len(m) < 2:
            rows.append({"dataset": dataset, "method_a": args.method_a, "method_b": args.method_b, "metric": args.metric,
                         "n_pairs": len(m), "mean_a": np.nan, "mean_b": np.nan, "mean_diff_a_minus_b": np.nan,
                         "paired_t_p": np.nan, "wilcoxon_p": np.nan, "note": "not enough paired runs"})
            continue
        diff = m["a"].to_numpy() - m["b"].to_numpy()
        try:
            t_p = ttest_rel(m["a"], m["b"], nan_policy="omit").pvalue
        except Exception:
            t_p = np.nan
        try:
            w_p = wilcoxon(diff).pvalue
        except Exception:
            w_p = np.nan
        rows.append({"dataset": dataset, "method_a": args.method_a, "method_b": args.method_b, "metric": args.metric,
                     "n_pairs": len(m), "mean_a": m["a"].mean(), "std_a": m["a"].std(ddof=1),
                     "mean_b": m["b"].mean(), "std_b": m["b"].std(ddof=1),
                     "mean_diff_a_minus_b": diff.mean(), "std_diff": diff.std(ddof=1),
                     "paired_t_p": t_p, "wilcoxon_p": w_p, "note": "paired by seed+fold"})
    out = pd.DataFrame(rows)
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.out_csv, index=False)
    print(out.to_string(index=False))
    print(f"\nSaved: {args.out_csv}")

if __name__ == "__main__":
    main()
