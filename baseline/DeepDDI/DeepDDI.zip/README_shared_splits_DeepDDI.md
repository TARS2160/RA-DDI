# DeepDDI on shared splits

This patch does **not** use the original pretrained `data/models/ddi_model.h5` for benchmark numbers.
It retrains a DeepDDI-style MLP from scratch on each shared `prepared.csv + seed/fold.npz` split.

## Why
Reviewer-safe setting:
1. same rows and same negative sampling: `prepared/<dataset>_prepared.csv` is the source of truth;
2. same split: `splits/<dataset>/seed_<seed>_fold_<fold>.npz` indices are used directly;
3. same metrics: every run writes the same metric columns to `metrics.csv`;
4. repeated runs: run all 15 split files and summarize mean ± std; use paired tests by seed+fold.

## Main script
`train_deepddi_shared_splits.py`

Input features are the original DeepDDI 100-d pair features:
`[drug1 PC_1...PC_50, drug2 PC_1...PC_50]` from `data/drug_tanimoto_PCA50.csv`.
The classifier is the original DeepDDI MLP idea: 4 × Dense(1024)-ReLU-Dropout(0.3), then task-specific softmax output.

## Important reporting note
If a prepared dataset contains drugs absent from `data/drug_tanimoto_PCA50.csv`, the default script keeps the split unchanged and uses zero-vector imputation for missing PCA features. It writes:
- `feature_report.json`
- `missing_feature_drugs.csv`

Report this in the baseline input-setting table. If you want to forbid imputation, run with `--missing_strategy error`.
