# -*- coding: utf-8 -*-
"""Train SkipGNN on one prepared shared split.

Strict protocol implemented here:
- reads the exact shared train/validation/test indices from NPZ;
- never re-samples positive/negative examples;
- constructs SkipGNN's DDI graph from training pairs only;
- for PDD-Graph, only positive (label=1) training pairs become graph edges;
- validation/test edges and labels never enter graph construction;
- reports the same six metrics used by RA-DDI;
- selects the checkpoint only on validation Macro-F1;
- saves one result row keyed by dataset/seed/fold for paired statistics.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import math
import os
import random
import sys
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import scipy.sparse as sp
import torch
import torch.nn as nn
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)

from models_shared import SkipGNNShared


REQUIRED_COLUMNS = {
    "sample_id",
    "drug1_id_std",
    "drug2_id_std",
    "label_id",
    "pair_group",
}

METRIC_COLUMNS = [
    "accuracy",
    "auc_roc",
    "auc_pr",
    "macro_f1",
    "macro_precision",
    "macro_recall",
]


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--dataset", required=True)
    p.add_argument("--shared_dir", required=True, help="Directory containing prepared/ and splits/")
    p.add_argument("--split_npz", default=None, help="Optional explicit NPZ path")
    p.add_argument("--output_dir", required=True)
    p.add_argument("--results_csv", default=None, help="Master per-fold results CSV")

    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--patience", type=int, default=8)
    p.add_argument("--min_delta", type=float, default=1e-5)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--weight_decay", type=float, default=5e-4)
    p.add_argument("--hidden1", type=int, default=64)
    p.add_argument("--hidden2", type=int, default=16)
    p.add_argument("--hidden_decode1", type=int, default=512)
    p.add_argument("--dropout", type=float, default=0.5)
    p.add_argument("--pair_chunk_size", type=int, default=65536)
    p.add_argument("--class_weight", choices=["none", "balanced"], default="none")
    p.add_argument("--symmetric_decoder", action="store_true")
    p.add_argument("--grad_clip", type=float, default=5.0)

    p.add_argument("--device", default="cuda")
    p.add_argument("--num_threads", type=int, default=0)
    p.add_argument("--allow_pair_overlap", action="store_true",
                   help="Diagnostic only. Do not use for reviewer-facing strict experiments.")
    p.add_argument("--save_predictions", action="store_true")
    p.add_argument("--max_train_pairs_per_epoch", type=int, default=0,
                   help="0 uses all training pairs. Nonzero is debugging only.")
    p.add_argument("--overwrite", action="store_true")
    return p.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def canonical_pair(a: str, b: str) -> str:
    a, b = str(a).strip(), str(b).strip()
    return "||".join(sorted((a, b)))


def stable_hash(values: np.ndarray) -> str:
    arr = np.ascontiguousarray(values)
    return hashlib.sha256(arr.view(np.uint8)).hexdigest()


def load_split(path: Path) -> Tuple[np.ndarray, np.ndarray, np.ndarray, int, int, int]:
    with np.load(path, allow_pickle=False) as z:
        missing = {"train_idx", "val_idx", "test_idx"} - set(z.files)
        if missing:
            raise ValueError(f"{path} missing arrays: {sorted(missing)}")
        train_idx = np.asarray(z["train_idx"], dtype=np.int64)
        val_idx = np.asarray(z["val_idx"], dtype=np.int64)
        test_idx = np.asarray(z["test_idx"], dtype=np.int64)
        seed = int(np.asarray(z["seed"]).reshape(-1)[0]) if "seed" in z.files else -1
        fold = int(np.asarray(z["fold"]).reshape(-1)[0]) if "fold" in z.files else -1
        group_split = int(np.asarray(z["group_split"]).reshape(-1)[0]) if "group_split" in z.files else -1
    return train_idx, val_idx, test_idx, seed, fold, group_split


def validate_indices(n: int, train_idx: np.ndarray, val_idx: np.ndarray, test_idx: np.ndarray) -> None:
    for name, idx in (("train", train_idx), ("val", val_idx), ("test", test_idx)):
        if idx.ndim != 1:
            raise ValueError(f"{name}_idx must be 1D")
        if len(np.unique(idx)) != len(idx):
            raise ValueError(f"{name}_idx contains duplicate row indices")
        if len(idx) and (idx.min() < 0 or idx.max() >= n):
            raise IndexError(f"{name}_idx out of range for prepared rows={n}")
    if (
        np.intersect1d(train_idx, val_idx, assume_unique=True).size
        or np.intersect1d(train_idx, test_idx, assume_unique=True).size
        or np.intersect1d(val_idx, test_idx, assume_unique=True).size
    ):
        raise ValueError("train/val/test row indices are not disjoint")
    if len(train_idx) + len(val_idx) + len(test_idx) != n:
        raise ValueError(
            "split does not cover every prepared row exactly once: "
            f"train+val+test={len(train_idx)+len(val_idx)+len(test_idx)}, rows={n}"
        )


def pair_overlap_report(df: pd.DataFrame, train_idx: np.ndarray, val_idx: np.ndarray, test_idx: np.ndarray) -> Dict[str, int]:
    # Integer factorization avoids building several million-entry Python string sets.
    pair_codes, _ = pd.factorize(df["pair_group"].astype(str), sort=False)
    train_pairs = np.unique(pair_codes[train_idx])
    val_pairs = np.unique(pair_codes[val_idx])
    test_pairs = np.unique(pair_codes[test_idx])
    return {
        "train_val_pair_overlap": int(np.intersect1d(train_pairs, val_pairs, assume_unique=True).size),
        "train_test_pair_overlap": int(np.intersect1d(train_pairs, test_pairs, assume_unique=True).size),
        "val_test_pair_overlap": int(np.intersect1d(val_pairs, test_pairs, assume_unique=True).size),
    }


def build_node_map(df: pd.DataFrame) -> Tuple[Dict[str, int], np.ndarray]:
    d1 = df["drug1_id_std"].astype(str).str.strip()
    d2 = df["drug2_id_std"].astype(str).str.strip()
    nodes = np.array(sorted(set(d1) | set(d2)), dtype=object)
    node_map = {node: i for i, node in enumerate(nodes.tolist())}
    return node_map, nodes


def map_pairs(df: pd.DataFrame, node_map: Dict[str, int]) -> np.ndarray:
    left = df["drug1_id_std"].astype(str).str.strip().map(node_map)
    right = df["drug2_id_std"].astype(str).str.strip().map(node_map)
    if left.isna().any() or right.isna().any():
        raise ValueError("failed to map one or more drug IDs")
    return np.column_stack((left.to_numpy(np.int64), right.to_numpy(np.int64)))


def normalize_adj(adj: sp.spmatrix) -> sp.coo_matrix:
    adj = adj.tocoo().astype(np.float32)
    rowsum = np.asarray(adj.sum(1)).reshape(-1)
    d_inv_sqrt = np.zeros_like(rowsum, dtype=np.float32)
    positive = rowsum > 0
    d_inv_sqrt[positive] = np.power(rowsum[positive], -0.5)
    d_inv_sqrt[~np.isfinite(d_inv_sqrt)] = 0.0
    d = sp.diags(d_inv_sqrt)
    return (d @ adj @ d).tocoo()


def scipy_to_torch_sparse(matrix: sp.spmatrix, device: torch.device) -> torch.Tensor:
    coo = matrix.tocoo().astype(np.float32)
    indices = torch.from_numpy(np.vstack((coo.row, coo.col)).astype(np.int64))
    values = torch.from_numpy(coo.data)
    tensor = torch.sparse_coo_tensor(indices, values, size=coo.shape, dtype=torch.float32)
    return tensor.coalesce().to(device)


def build_training_graph(
    dataset: str,
    pairs: np.ndarray,
    labels: np.ndarray,
    train_idx: np.ndarray,
    num_nodes: int,
) -> Tuple[sp.coo_matrix, sp.coo_matrix, np.ndarray]:
    if dataset == "pdd_graph_2class":
        edge_rows = train_idx[labels[train_idx] == 1]
    else:
        # Multi-class files contain typed known interactions; all training rows are graph edges.
        edge_rows = train_idx

    edge_pairs = pairs[edge_rows]
    data = np.ones(len(edge_pairs), dtype=np.float32)
    adj = sp.coo_matrix(
        (data, (edge_pairs[:, 0], edge_pairs[:, 1])),
        shape=(num_nodes, num_nodes),
        dtype=np.float32,
    ).tocsr()
    adj = adj.maximum(adj.T)
    adj.data[:] = 1.0

    # Original graph receives self-loops before symmetric normalization.
    original = adj + sp.eye(num_nodes, dtype=np.float32, format="csr")
    original.data[:] = 1.0

    # Released code forms the skip graph from A^2 before self-loops are added to A.
    skip = (adj @ adj).tocsr()
    skip.data[:] = 1.0
    skip.eliminate_zeros()

    return normalize_adj(original), normalize_adj(skip), edge_rows


def compute_class_weights(labels: np.ndarray, num_classes: int, mode: str, device: torch.device) -> Optional[torch.Tensor]:
    if mode == "none":
        return None
    counts = np.bincount(labels, minlength=num_classes).astype(np.float64)
    if np.any(counts == 0):
        raise ValueError(f"cannot compute balanced weights because a training class is absent: {counts.tolist()}")
    weights = len(labels) / (num_classes * counts)
    return torch.tensor(weights, dtype=torch.float32, device=device)


def iter_chunks(indices: np.ndarray, chunk_size: int) -> Iterable[np.ndarray]:
    for start in range(0, len(indices), chunk_size):
        yield indices[start : start + chunk_size]


def train_one_epoch(
    model: SkipGNNShared,
    original_adj: torch.Tensor,
    skip_adj: torch.Tensor,
    pairs: np.ndarray,
    labels: np.ndarray,
    train_rows: np.ndarray,
    optimizer: torch.optim.Optimizer,
    criterion: nn.Module,
    chunk_size: int,
    grad_clip: float,
) -> float:
    model.train()
    optimizer.zero_grad(set_to_none=True)
    node_embeddings = model.encode(original_adj, skip_adj)
    device = node_embeddings.device
    total = len(train_rows)
    loss_sum = 0.0

    for start in range(0, total, chunk_size):
        rows = train_rows[start : start + chunk_size]
        pair_tensor = torch.as_tensor(pairs[rows], dtype=torch.long, device=device)
        label_tensor = torch.as_tensor(labels[rows], dtype=torch.long, device=device)
        logits = model.decode_embeddings(node_embeddings, pair_tensor)
        raw_loss = criterion(logits, label_tensor)
        # criterion uses reduction='sum'; divide by total to equal full-data mean loss.
        scaled_loss = raw_loss / float(total)
        is_last = start + chunk_size >= total
        scaled_loss.backward(retain_graph=not is_last)
        loss_sum += float(raw_loss.detach().cpu())

    if grad_clip > 0:
        torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
    optimizer.step()
    return loss_sum / float(total)


@torch.no_grad()
def predict_rows(
    model: SkipGNNShared,
    original_adj: torch.Tensor,
    skip_adj: torch.Tensor,
    pairs: np.ndarray,
    labels: np.ndarray,
    rows: np.ndarray,
    chunk_size: int,
    criterion: nn.Module,
) -> Tuple[np.ndarray, np.ndarray, float]:
    model.eval()
    embeddings = model.encode(original_adj, skip_adj)
    device = embeddings.device
    probs: List[np.ndarray] = []
    y_true: List[np.ndarray] = []
    loss_sum = 0.0

    for chunk in iter_chunks(rows, chunk_size):
        pair_tensor = torch.as_tensor(pairs[chunk], dtype=torch.long, device=device)
        label_tensor = torch.as_tensor(labels[chunk], dtype=torch.long, device=device)
        logits = model.decode_embeddings(embeddings, pair_tensor)
        loss_sum += float(criterion(logits, label_tensor).detach().cpu())
        probs.append(torch.softmax(logits, dim=1).cpu().numpy().astype(np.float32, copy=False))
        y_true.append(labels[chunk].astype(np.int64, copy=False))

    return np.concatenate(y_true), np.concatenate(probs), loss_sum / float(len(rows))


def safe_auc_metrics(y_true: np.ndarray, prob: np.ndarray, num_classes: int) -> Tuple[float, float]:
    try:
        if num_classes == 2:
            auc_roc = roc_auc_score(y_true, prob[:, 1])
            auc_pr = average_precision_score(y_true, prob[:, 1])
        else:
            one_hot = np.eye(num_classes, dtype=np.int8)[y_true]
            auc_roc = roc_auc_score(one_hot, prob, average="macro", multi_class="ovr")
            auc_pr = average_precision_score(one_hot, prob, average="macro")
    except ValueError:
        auc_roc, auc_pr = float("nan"), float("nan")
    return float(auc_roc), float(auc_pr)


def calculate_metrics(y_true: np.ndarray, prob: np.ndarray, num_classes: int) -> Dict[str, float]:
    pred = np.argmax(prob, axis=1)
    auc_roc, auc_pr = safe_auc_metrics(y_true, prob, num_classes)
    return {
        "accuracy": float(accuracy_score(y_true, pred)),
        "auc_roc": auc_roc,
        "auc_pr": auc_pr,
        "macro_f1": float(f1_score(y_true, pred, average="macro", zero_division=0)),
        "macro_precision": float(precision_score(y_true, pred, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(y_true, pred, average="macro", zero_division=0)),
    }


def save_json(path: Path, obj: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=True)
    os.replace(tmp, path)


def upsert_results_csv(path: Path, row: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        old = pd.read_csv(path)
        key_cols = ["method", "dataset", "seed", "fold"]
        if all(c in old.columns for c in key_cols):
            mask = np.ones(len(old), dtype=bool)
            for c in key_cols:
                mask &= old[c].astype(str).to_numpy() == str(row[c])
            old = old.loc[~mask]
        out = pd.concat([old, pd.DataFrame([row])], ignore_index=True)
    else:
        out = pd.DataFrame([row])
    sort_cols = [c for c in ["dataset", "seed", "fold"] if c in out.columns]
    if sort_cols:
        out = out.sort_values(sort_cols).reset_index(drop=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    out.to_csv(tmp, index=False, encoding="utf-8-sig")
    os.replace(tmp, path)


def main() -> None:
    args = parse_args()
    if args.num_threads > 0:
        torch.set_num_threads(args.num_threads)

    shared_dir = Path(args.shared_dir)
    prepared_path = shared_dir / "prepared" / f"{args.dataset}_prepared.csv"
    if not prepared_path.exists():
        raise FileNotFoundError(prepared_path)

    if args.split_npz:
        split_path = Path(args.split_npz)
    else:
        raise ValueError("--split_npz is required so the exact shared split is explicit")
    if not split_path.exists():
        raise FileNotFoundError(split_path)

    train_idx, val_idx, test_idx, seed, fold, group_split = load_split(split_path)
    if seed < 0 or fold < 0:
        raise ValueError("split NPZ must contain seed and fold")
    set_seed(seed)

    device = torch.device(args.device if args.device != "cuda" or torch.cuda.is_available() else "cpu")
    output_root = Path(args.output_dir) / args.dataset / f"seed_{seed}_fold_{fold}"
    result_json = output_root / "result.json"
    if result_json.exists() and not args.overwrite:
        print(f"[SKIP] Result exists: {result_json}")
        return
    output_root.mkdir(parents=True, exist_ok=True)

    print(f"Loading prepared data: {prepared_path}")
    df = pd.read_csv(prepared_path, usecols=lambda c: c in REQUIRED_COLUMNS, low_memory=False)
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"prepared CSV missing columns: {sorted(missing)}")
    if not np.array_equal(df["sample_id"].to_numpy(np.int64), np.arange(len(df), dtype=np.int64)):
        raise ValueError("sample_id must equal prepared CSV row position; do not sort/filter after split generation")

    validate_indices(len(df), train_idx, val_idx, test_idx)
    labels = df["label_id"].to_numpy(np.int64)
    unique_labels = np.unique(labels)
    if not np.array_equal(unique_labels, np.arange(unique_labels.max() + 1)):
        raise ValueError(f"label_id must be contiguous from 0, found {unique_labels.tolist()}")
    num_classes = int(unique_labels.max() + 1)

    overlap = pair_overlap_report(df, train_idx, val_idx, test_idx)
    overlap_total = sum(overlap.values())
    if overlap_total and not args.allow_pair_overlap:
        raise RuntimeError(
            "Strict pair-disjoint audit failed. The shared split places the same unordered drug pair "
            f"in different subsets: {overlap}. Regenerate ALL methods' shared splits with "
            "generate_shared_splits.py --group_split. Do not bypass this for the reviewer-facing run."
        )

    node_map, node_ids = build_node_map(df)
    pairs = map_pairs(df, node_map)
    original_sp, skip_sp, graph_edge_rows = build_training_graph(
        args.dataset, pairs, labels, train_idx, len(node_ids)
    )

    # Explicit audit that every graph edge row belongs to training and never to val/test.
    if np.setdiff1d(graph_edge_rows, train_idx, assume_unique=False).size:
        raise AssertionError("graph construction used a non-training row")
    if (
        np.intersect1d(graph_edge_rows, val_idx, assume_unique=False).size
        or np.intersect1d(graph_edge_rows, test_idx, assume_unique=False).size
    ):
        raise AssertionError("validation/test rows entered the training graph")

    audit = {
        "dataset": args.dataset,
        "prepared_csv": str(prepared_path.resolve()),
        "split_npz": str(split_path.resolve()),
        "seed": seed,
        "fold": fold,
        "group_split_flag_in_npz": group_split,
        "prepared_rows": len(df),
        "train_rows": len(train_idx),
        "val_rows": len(val_idx),
        "test_rows": len(test_idx),
        "train_idx_sha256": stable_hash(train_idx),
        "val_idx_sha256": stable_hash(val_idx),
        "test_idx_sha256": stable_hash(test_idx),
        "pair_overlap": overlap,
        "allow_pair_overlap": bool(args.allow_pair_overlap),
        "negative_sampling": (
            "No online negative sampling. PDD uses the fixed prepared positive/negative sample set; "
            "only label=1 training rows form graph edges."
            if args.dataset == "pdd_graph_2class"
            else "Not applicable: every prepared row is a typed known DDI; no online sampling."
        ),
        "graph_input": "training DDI topology only",
        "graph_edge_rows": int(len(graph_edge_rows)),
        "graph_uses_val_or_test_rows": False,
        "num_nodes_transductive_vocabulary": int(len(node_ids)),
        "original_adj_nnz": int(original_sp.nnz),
        "skip_adj_nnz": int(skip_sp.nnz),
        "metrics": METRIC_COLUMNS,
    }
    save_json(output_root / "protocol_audit.json", audit)

    original_adj = scipy_to_torch_sparse(original_sp, device)
    skip_adj = scipy_to_torch_sparse(skip_sp, device)

    model = SkipGNNShared(
        num_nodes=len(node_ids),
        num_classes=num_classes,
        hidden1=args.hidden1,
        hidden2=args.hidden2,
        hidden_decode1=args.hidden_decode1,
        dropout=args.dropout,
        symmetric_decoder=args.symmetric_decoder,
    ).to(device)

    weights = compute_class_weights(labels[train_idx], num_classes, args.class_weight, device)
    train_criterion = nn.CrossEntropyLoss(weight=weights, reduction="sum")
    eval_criterion = nn.CrossEntropyLoss(reduction="sum")
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    train_rows_epoch = train_idx.copy()
    if args.max_train_pairs_per_epoch > 0:
        if args.max_train_pairs_per_epoch >= len(train_idx):
            train_rows_epoch = train_idx.copy()
        else:
            rng = np.random.default_rng(seed)
            train_rows_epoch = rng.choice(train_idx, size=args.max_train_pairs_per_epoch, replace=False)
        print("[WARNING] max_train_pairs_per_epoch is debugging-only and not strict full-data training.")

    best_state: Optional[Dict[str, torch.Tensor]] = None
    best_val_f1 = -math.inf
    best_epoch = -1
    no_improve = 0
    history: List[Dict] = []
    start_time = time.time()

    print("=" * 88)
    print(f"SkipGNN shared split | dataset={args.dataset} | seed={seed} | fold={fold}")
    print(f"device={device} | nodes={len(node_ids)} | classes={num_classes}")
    print(f"train={len(train_idx)} val={len(val_idx)} test={len(test_idx)} graph_edges={len(graph_edge_rows)}")
    print(f"pair overlap audit={overlap}")
    print("=" * 88)

    for epoch in range(1, args.epochs + 1):
        epoch_start = time.time()
        train_loss = train_one_epoch(
            model, original_adj, skip_adj, pairs, labels, train_rows_epoch,
            optimizer, train_criterion, args.pair_chunk_size, args.grad_clip,
        )
        y_val, p_val, val_loss = predict_rows(
            model, original_adj, skip_adj, pairs, labels, val_idx,
            args.pair_chunk_size, eval_criterion,
        )
        val_metrics = calculate_metrics(y_val, p_val, num_classes)
        row = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_loss": val_loss,
            **{f"val_{k}": v for k, v in val_metrics.items()},
            "seconds": time.time() - epoch_start,
        }
        history.append(row)
        print(
            f"Epoch {epoch:03d} | train_loss={train_loss:.6f} | val_loss={val_loss:.6f} | "
            f"val_acc={val_metrics['accuracy']:.6f} | val_macro_f1={val_metrics['macro_f1']:.6f} | "
            f"{row['seconds']:.1f}s"
        )

        if val_metrics["macro_f1"] > best_val_f1 + args.min_delta:
            best_val_f1 = val_metrics["macro_f1"]
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= args.patience:
                print(f"Early stopping at epoch {epoch}; best epoch={best_epoch}, val_macro_f1={best_val_f1:.6f}")
                break

    if best_state is None:
        raise RuntimeError("training did not produce a valid checkpoint")
    model.load_state_dict(best_state)
    model.to(device)

    y_test, p_test, test_loss = predict_rows(
        model, original_adj, skip_adj, pairs, labels, test_idx,
        args.pair_chunk_size, eval_criterion,
    )
    metrics = calculate_metrics(y_test, p_test, num_classes)
    pred_test = np.argmax(p_test, axis=1)

    hyperparameters = {
        "epochs_max": args.epochs,
        "patience": args.patience,
        "min_delta": args.min_delta,
        "lr": args.lr,
        "weight_decay": args.weight_decay,
        "hidden1": args.hidden1,
        "hidden2": args.hidden2,
        "hidden_decode1": args.hidden_decode1,
        "dropout": args.dropout,
        "pair_chunk_size": args.pair_chunk_size,
        "class_weight": args.class_weight,
        "symmetric_decoder": args.symmetric_decoder,
        "max_train_pairs_per_epoch": args.max_train_pairs_per_epoch,
    }
    result = {
        "method": "SkipGNN",
        "dataset": args.dataset,
        "seed": seed,
        "fold": fold,
        "best_epoch": best_epoch,
        "best_val_macro_f1": best_val_f1,
        "test_loss": test_loss,
        **metrics,
        "train_size": len(train_idx),
        "val_size": len(val_idx),
        "test_size": len(test_idx),
        "num_nodes": len(node_ids),
        "num_classes": num_classes,
        "graph_edge_rows": len(graph_edge_rows),
        "group_split": group_split,
        "runtime_seconds": time.time() - start_time,
        "hyperparameters_json": json.dumps(hyperparameters, ensure_ascii=False, sort_keys=True),
        "split_npz": str(split_path.resolve()),
        "prepared_csv": str(prepared_path.resolve()),
        "strict_pair_disjoint": overlap_total == 0,
        "negative_sampling": audit["negative_sampling"],
        "input_information": "training DDI graph topology + implicit one-hot node identity",
    }

    pd.DataFrame(history).to_csv(output_root / "history.csv", index=False, encoding="utf-8-sig")
    save_json(result_json, result)
    torch.save(
        {
            "state_dict": best_state,
            "node_ids": node_ids.tolist(),
            "num_classes": num_classes,
            "hyperparameters": hyperparameters,
            "dataset": args.dataset,
            "seed": seed,
            "fold": fold,
        },
        output_root / "best_model.pt",
    )

    if args.save_predictions:
        pred_df = pd.DataFrame({
            "sample_id": df.iloc[test_idx]["sample_id"].to_numpy(),
            "y_true": y_test,
            "y_pred": pred_test,
        })
        for c in range(num_classes):
            pred_df[f"prob_class_{c}"] = p_test[:, c]
        pred_df.to_csv(output_root / "test_predictions.csv", index=False, encoding="utf-8-sig")

    results_csv = Path(args.results_csv) if args.results_csv else Path(args.output_dir) / "skipgnn_fold_results.csv"
    upsert_results_csv(results_csv, result)

    print("\nTest metrics")
    for key in METRIC_COLUMNS:
        print(f"  {key}: {metrics[key]:.6f}")
    print(f"Saved: {result_json}")
    print(f"Master CSV: {results_csv}")


if __name__ == "__main__":
    main()
