# -*- coding: utf-8 -*-
"""Aggregate mean±std and perform matched significance tests."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

METRICS = ["accuracy", "auc_roc", "auc_pr", "macro_f1", "macro_precision", "macro_recall"]
ALIASES = {
    "accuracy": ["accuracy", "acc", "Accuracy"],
    "auc_roc": ["auc_roc", "auc", "AUC", "roc_auc", "AUC-ROC"],
    "auc_pr": ["auc_pr", "aupr", "AUPR", "pr_auc", "AUC-PR"],
    "macro_f1": ["macro_f1", "f1", "F1", "Macro-F1"],
    "macro_precision": ["macro_precision", "precision", "Macro-Precision"],
    "macro_recall": ["macro_recall", "recall", "Macro-Recall"],
}


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--skipgnn_csv", required=True)
    p.add_argument("--output_dir", required=True)
    p.add_argument("--reference_csv", default=None, help="RA-DDI or another method's per-fold CSV")
    p.add_argument("--reference_method", default="RA-DDI")
    p.add_argument("--train_fraction", type=float, default=0.70)
    p.add_argument("--test_fraction", type=float, default=0.20)
    return p.parse_args()


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for target, candidates in ALIASES.items():
        if target in out.columns:
            continue
        for c in candidates:
            if c in out.columns:
                out[target] = pd.to_numeric(out[c], errors="coerce")
                break
    rename = {}
    for c in out.columns:
        lc = c.lower()
        if lc == "split_seed": rename[c] = "seed"
        elif lc in {"fold_id", "fold_index"}: rename[c] = "fold"
        elif lc in {"dataset_name", "data"}: rename[c] = "dataset"
    return out.rename(columns=rename)


def aggregate(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for dataset, g in df.groupby("dataset"):
        row = {"dataset": dataset, "n_splits": len(g)}
        for m in METRICS:
            vals = pd.to_numeric(g[m], errors="coerce").dropna()
            row[f"{m}_mean"] = vals.mean()
            row[f"{m}_std"] = vals.std(ddof=1)
            row[f"{m}_mean_std"] = f"{vals.mean():.4f} ± {vals.std(ddof=1):.4f}"
        rows.append(row)
    return pd.DataFrame(rows)


def corrected_repeated_kfold_ttest(diff: np.ndarray, test_train_ratio: float):
    diff = np.asarray(diff, dtype=float)
    diff = diff[np.isfinite(diff)]
    n = len(diff)
    if n < 2:
        return np.nan, np.nan
    variance = np.var(diff, ddof=1)
    denom = np.sqrt((1.0 / n + test_train_ratio) * variance)
    if denom == 0:
        return (np.inf if diff.mean() > 0 else -np.inf if diff.mean() < 0 else 0.0), (0.0 if diff.mean() != 0 else 1.0)
    t_stat = diff.mean() / denom
    p_value = 2.0 * stats.t.sf(abs(t_stat), df=n - 1)
    return float(t_stat), float(p_value)


def significance(skip: pd.DataFrame, ref: pd.DataFrame, ref_name: str, ratio: float) -> pd.DataFrame:
    key = ["dataset", "seed", "fold"]
    missing_skip = set(key) - set(skip.columns)
    missing_ref = set(key) - set(ref.columns)
    if missing_skip or missing_ref:
        raise ValueError(f"paired testing requires dataset/seed/fold. missing skip={missing_skip}, reference={missing_ref}")
    merged = skip.merge(ref, on=key, suffixes=("_skipgnn", "_reference"), how="inner")
    rows = []
    for dataset, g in merged.groupby("dataset"):
        for metric in METRICS:
            a = pd.to_numeric(g[f"{metric}_skipgnn"], errors="coerce").to_numpy(float)
            b = pd.to_numeric(g[f"{metric}_reference"], errors="coerce").to_numpy(float)
            mask = np.isfinite(a) & np.isfinite(b)
            a, b = a[mask], b[mask]
            diff = a - b
            if len(diff) < 2:
                continue
            paired_t = stats.ttest_rel(a, b)
            try:
                wilcoxon = stats.wilcoxon(diff, zero_method="wilcox", alternative="two-sided")
                w_stat, w_p = float(wilcoxon.statistic), float(wilcoxon.pvalue)
            except ValueError:
                w_stat, w_p = np.nan, 1.0
            corr_t, corr_p = corrected_repeated_kfold_ttest(diff, ratio)
            sd = np.std(diff, ddof=1)
            cohen_dz = float(np.mean(diff) / sd) if sd > 0 else np.nan
            rows.append({
                "dataset": dataset,
                "comparison": f"SkipGNN - {ref_name}",
                "metric": metric,
                "n_matched_splits": len(diff),
                "skipgnn_mean": np.mean(a),
                "reference_mean": np.mean(b),
                "mean_difference": np.mean(diff),
                "paired_t_stat": float(paired_t.statistic),
                "paired_t_p": float(paired_t.pvalue),
                "wilcoxon_stat": w_stat,
                "wilcoxon_p": w_p,
                "corrected_repeated_kfold_t": corr_t,
                "corrected_repeated_kfold_p": corr_p,
                "cohen_dz": cohen_dz,
            })
    return pd.DataFrame(rows)


def main():
    args = parse_args()
    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    skip = normalize_columns(pd.read_csv(args.skipgnn_csv))
    missing = set(METRICS + ["dataset", "seed", "fold"]) - set(skip.columns)
    if missing:
        raise ValueError(f"SkipGNN CSV missing columns: {sorted(missing)}")

    summary = aggregate(skip)
    summary.to_csv(out_dir / "skipgnn_mean_std.csv", index=False, encoding="utf-8-sig")
    print(summary.to_string(index=False))

    if args.reference_csv:
        ref = normalize_columns(pd.read_csv(args.reference_csv))
        missing_ref = set(METRICS + ["dataset", "seed", "fold"]) - set(ref.columns)
        if missing_ref:
            raise ValueError(f"reference CSV missing columns after alias normalization: {sorted(missing_ref)}")
        ratio = args.test_fraction / args.train_fraction
        sig = significance(skip, ref, args.reference_method, ratio)
        sig.to_csv(out_dir / "skipgnn_significance_vs_reference.csv", index=False, encoding="utf-8-sig")
        print(f"\nSaved significance tests: {out_dir / 'skipgnn_significance_vs_reference.csv'}")


if __name__ == "__main__":
    main()
