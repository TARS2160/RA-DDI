# -*- coding: utf-8 -*-
"""Append or replace the SkipGNN row in method_input_setting_template.csv."""

import argparse
from pathlib import Path
import pandas as pd


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--shared_dir", required=True)
    p.add_argument("--hyperparameter_budget", default="1 fixed configuration; validation used only for early stopping")
    args = p.parse_args()

    path = Path(args.shared_dir) / "method_input_setting_template.csv"
    if path.exists():
        df = pd.read_csv(path)
        if "Method" in df.columns:
            df = df[df["Method"].astype(str).str.lower() != "skipgnn"]
    else:
        df = pd.DataFrame()

    row = {
        "Method": "SkipGNN",
        "CodeSource": "Released SkipGNN implementation adapted for shared NPZ splits and dataset-specific class counts",
        "InputInformation": "Training DDI graph topology + implicit one-hot node identity; no text, SMILES, or biomedical KG",
        "UsesText": "No",
        "UsesNoDDIKG": "No",
        "UsesTrainDDIGraph": "Yes; original and skip graphs are rebuilt separately for every fold from training edges only",
        "OutputLabelSpace": "Dataset-specific: 3/4/4/2 classes",
        "Split": "Exact train_idx/val_idx/test_idx from shared seed/fold NPZ",
        "NegativeSampling": "No online sampling; PDD uses the fixed prepared positive/negative rows, with only positive training rows used as graph edges",
        "HyperparameterBudget": args.hyperparameter_budget,
        "ValidationAndEarlyStopping": "Checkpoint selected by validation Macro-F1; test set evaluated once after selection",
        "Metrics": "Accuracy, AUC-ROC, AUC-PR, Macro-F1, Macro-Precision, Macro-Recall",
        "LeakageControl": "No validation/test pair is inserted into the graph; strict run fails if unordered pairs overlap across subsets",
        "ImplementationDetails": "Sparse normalized training adjacency; skip adjacency A^2; implicit one-hot features; full training sample set processed in chunks with one graph encoding per epoch",
    }
    out = pd.concat([df, pd.DataFrame([row])], ignore_index=True, sort=False)
    out.to_csv(path, index=False, encoding="utf-8-sig")
    print(f"Updated: {path}")


if __name__ == "__main__":
    main()
