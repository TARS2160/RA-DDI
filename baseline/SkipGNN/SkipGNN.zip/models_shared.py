"""SkipGNN model adapted for shared-split, multi-class DDI experiments.

The first graph-convolution layers receive one-hot node features in the original
implementation.  For an identity matrix I, I @ W == W, so this module performs
exactly the same operation without materialising a potentially large dense I.
"""

from __future__ import annotations

import math
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
from torch.nn.parameter import Parameter


class GraphConvolution(nn.Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.weight = Parameter(torch.empty(self.in_features, self.out_features))
        self.bias = Parameter(torch.empty(self.out_features)) if bias else None
        self.reset_parameters()

    def reset_parameters(self) -> None:
        stdv = 1.0 / math.sqrt(self.out_features)
        nn.init.uniform_(self.weight, -stdv, stdv)
        if self.bias is not None:
            nn.init.uniform_(self.bias, -stdv, stdv)

    def forward(self, x: Tensor, adj: Tensor) -> Tensor:
        support = x @ self.weight
        out = torch.sparse.mm(adj, support) if adj.is_sparse else adj @ support
        return out + self.bias if self.bias is not None else out


class IdentityGraphConvolution(nn.Module):
    """Graph convolution with implicit one-hot node features."""

    def __init__(self, num_nodes: int, out_features: int, bias: bool = True):
        super().__init__()
        self.num_nodes = int(num_nodes)
        self.out_features = int(out_features)
        self.weight = Parameter(torch.empty(self.num_nodes, self.out_features))
        self.bias = Parameter(torch.empty(self.out_features)) if bias else None
        self.reset_parameters()

    def reset_parameters(self) -> None:
        stdv = 1.0 / math.sqrt(self.out_features)
        nn.init.uniform_(self.weight, -stdv, stdv)
        if self.bias is not None:
            nn.init.uniform_(self.bias, -stdv, stdv)

    def forward(self, adj: Tensor) -> Tensor:
        out = torch.sparse.mm(adj, self.weight) if adj.is_sparse else adj @ self.weight
        return out + self.bias if self.bias is not None else out


class SkipGNNShared(nn.Module):
    """SkipGNN encoder plus a dataset-specific multi-class pair decoder."""

    def __init__(
        self,
        num_nodes: int,
        num_classes: int,
        hidden1: int = 64,
        hidden2: int = 32,
        hidden_decode1: int = 16,
        dropout: float = 0.5,
        symmetric_decoder: bool = False,
    ) -> None:
        super().__init__()
        self.num_nodes = int(num_nodes)
        self.num_classes = int(num_classes)
        self.dropout = float(dropout)
        self.symmetric_decoder = bool(symmetric_decoder)

        # Original graph branch and cross-updates.
        self.o_gc1 = IdentityGraphConvolution(num_nodes, hidden1)
        self.o_gc2 = GraphConvolution(hidden1, hidden2)
        self.o_gc1_s = GraphConvolution(hidden1, hidden1)

        # Skip graph branch and cross-updates.
        self.s_gc1 = IdentityGraphConvolution(num_nodes, hidden1)
        self.s_gc1_o = IdentityGraphConvolution(num_nodes, hidden1)
        self.s_gc2_o = GraphConvolution(hidden1, hidden2)

        decoder_in = hidden2 * 2
        self.decoder1 = nn.Linear(decoder_in, hidden_decode1)
        self.decoder2 = nn.Linear(hidden_decode1, num_classes)

    def encode(self, original_adj: Tensor, skip_adj: Tensor) -> Tensor:
        o_x = F.relu(self.o_gc1(original_adj) + self.s_gc1_o(skip_adj))
        s_x = F.relu(self.s_gc1(skip_adj) + self.o_gc1_s(o_x, original_adj))

        o_x = F.dropout(o_x, self.dropout, training=self.training)
        s_x = F.dropout(s_x, self.dropout, training=self.training)

        return self.o_gc2(o_x, original_adj) + self.s_gc2_o(s_x, skip_adj)

    def decode_embeddings(self, node_embeddings: Tensor, pair_index: Tensor) -> Tensor:
        if pair_index.ndim != 2 or pair_index.shape[1] != 2:
            raise ValueError(f"pair_index must have shape [N, 2], got {tuple(pair_index.shape)}")
        u = node_embeddings[pair_index[:, 0]]
        v = node_embeddings[pair_index[:, 1]]
        if self.symmetric_decoder:
            pair_feat = torch.cat((u + v, torch.abs(u - v)), dim=1)
        else:
            # Faithful to the released implementation: ordered concatenation.
            pair_feat = torch.cat((u, v), dim=1)
        return self.decoder2(self.decoder1(pair_feat))

    def forward(self, original_adj: Tensor, skip_adj: Tensor, pair_index: Tensor) -> Tuple[Tensor, Tensor]:
        node_embeddings = self.encode(original_adj, skip_adj)
        logits = self.decode_embeddings(node_embeddings, pair_index)
        return logits, node_embeddings
