# -*- coding: utf-8 -*-
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path


PROJECT_DIR = Path(
    r"C:\Users\coin_reverse\Desktop\gyw\RA-DDI\baseline\SkipGNN-main"
)
TRAIN_SCRIPT = PROJECT_DIR / "train_skipgnn_shared_splits.py"

SHARED_DIR = Path(
    r"C:\Users\coin_reverse\Desktop\gyw\RA-DDI\baseline\split"
)
SPLIT_ROOT = SHARED_DIR / "splits"
OUTPUT_DIR = PROJECT_DIR / "strict_results" / "SkipGNN"


DATASETS = [
    {
        "name": "ddinter_4class",
        "allow_pair_overlap": False,
    },
    {
        "name": "drugbank_3class",
        "allow_pair_overlap": True,
    },
    {
        "name": "pdd_graph_2class",
        "allow_pair_overlap": True,
    },
]

SEEDS = [42, 43, 44]
FOLDS = [1, 2, 3, 4, 5]

EPOCHS = 50
PATIENCE = 8
LR = 0.0005
WEIGHT_DECAY = 0.0005
HIDDEN1 = 64
HIDDEN2 = 16
HIDDEN_DECODE1 = 512
DROPOUT = 0.5
PAIR_CHUNK_SIZE = 65536
CLASS_WEIGHT = "none"
DEVICE = "cuda"

# True：添加 --overwrite，已有同名结果也会重新运行并覆盖。
OVERWRITE = True

# True：某个任务失败后继续下一任务。
CONTINUE_ON_ERROR = True


def build_command(
    dataset: str,
    split_npz: Path,
    allow_pair_overlap: bool,
) -> list[str]:
    command = [
        sys.executable,
        str(TRAIN_SCRIPT),
        "--dataset",
        dataset,
        "--shared_dir",
        str(SHARED_DIR),
        "--split_npz",
        str(split_npz),
        "--output_dir",
        str(OUTPUT_DIR),
        "--epochs",
        str(EPOCHS),
        "--patience",
        str(PATIENCE),
        "--lr",
        str(LR),
        "--weight_decay",
        str(WEIGHT_DECAY),
        "--hidden1",
        str(HIDDEN1),
        "--hidden2",
        str(HIDDEN2),
        "--hidden_decode1",
        str(HIDDEN_DECODE1),
        "--dropout",
        str(DROPOUT),
        "--pair_chunk_size",
        str(PAIR_CHUNK_SIZE),
    ]

    if allow_pair_overlap:
        command.append("--allow_pair_overlap")

    command.extend(
        [
            "--class_weight",
            CLASS_WEIGHT,
            "--device",
            DEVICE,
        ]
    )

    if OVERWRITE:
        command.append("--overwrite")

    return command


def format_duration(seconds: float) -> str:
    seconds = int(seconds)
    hours, remainder = divmod(seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{seconds:02d}"


def main() -> int:
    if not PROJECT_DIR.exists():
        print(f"[ERROR] 项目目录不存在：{PROJECT_DIR}")
        return 1

    if not TRAIN_SCRIPT.exists():
        print(f"[ERROR] 找不到训练脚本：{TRAIN_SCRIPT}")
        return 1

    if not SHARED_DIR.exists():
        print(f"[ERROR] 找不到共享数据目录：{SHARED_DIR}")
        return 1

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    tasks: list[dict[str, object]] = []
    for dataset_config in DATASETS:
        dataset = str(dataset_config["name"])
        allow_pair_overlap = bool(dataset_config["allow_pair_overlap"])

        for seed in SEEDS:
            for fold in FOLDS:
                split_npz = (
                    SPLIT_ROOT
                    / dataset
                    / f"seed_{seed}_fold_{fold}.npz"
                )
                tasks.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "fold": fold,
                        "split_npz": split_npz,
                        "allow_pair_overlap": allow_pair_overlap,
                    }
                )

    total_tasks = len(tasks)
    succeeded: list[dict[str, object]] = []
    failed: list[dict[str, object]] = []
    batch_start = time.time()

    print("=" * 90)
    print("SkipGNN 统一 15 折批量训练")
    print(f"当前 Python  ：{sys.executable}")
    print(f"训练脚本     ：{TRAIN_SCRIPT}")
    print(f"共享数据目录 ：{SHARED_DIR}")
    print(f"结果目录     ：{OUTPUT_DIR}")
    print(f"任务总数     ：{total_tasks}")
    print("=" * 90)

    for task_index, task in enumerate(tasks, start=1):
        dataset = str(task["dataset"])
        seed = int(task["seed"])
        fold = int(task["fold"])
        split_npz = Path(task["split_npz"])
        allow_pair_overlap = bool(task["allow_pair_overlap"])

        print()
        print("=" * 90)
        print(
            f"[{task_index}/{total_tasks}] "
            f"dataset={dataset}, seed={seed}, fold={fold}"
        )
        print(f"split 文件：{split_npz}")
        print("=" * 90)

        if not split_npz.exists():
            reason = f"找不到 split 文件：{split_npz}"
            print(f"[FAILED] {reason}")
            failed.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    "fold": fold,
                    "reason": reason,
                }
            )
            if not CONTINUE_ON_ERROR:
                break
            continue

        command = build_command(
            dataset=dataset,
            split_npz=split_npz,
            allow_pair_overlap=allow_pair_overlap,
        )

        print("实际执行命令：")
        print(subprocess.list2cmdline(command))
        print()

        task_start = time.time()

        try:
            # 不捕获输出，因此训练日志会像手动执行一样直接显示。
            result = subprocess.run(
                command,
                cwd=str(PROJECT_DIR),
                check=False,
            )
            elapsed = time.time() - task_start

            if result.returncode == 0:
                succeeded.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "fold": fold,
                    }
                )
                print(
                    f"[SUCCESS] {dataset}, seed={seed}, fold={fold}，"
                    f"用时 {format_duration(elapsed)}"
                )
            else:
                reason = f"训练进程退出码为 {result.returncode}"
                failed.append(
                    {
                        "dataset": dataset,
                        "seed": seed,
                        "fold": fold,
                        "reason": reason,
                    }
                )
                print(
                    f"[FAILED] {dataset}, seed={seed}, fold={fold}，"
                    f"{reason}，用时 {format_duration(elapsed)}"
                )
                if not CONTINUE_ON_ERROR:
                    break

        except KeyboardInterrupt:
            print("\n[STOP] 用户手动终止了批量训练。")
            return 130

        except Exception as exc:
            elapsed = time.time() - task_start
            reason = f"{type(exc).__name__}: {exc}"
            failed.append(
                {
                    "dataset": dataset,
                    "seed": seed,
                    "fold": fold,
                    "reason": reason,
                }
            )
            print(
                f"[FAILED] {dataset}, seed={seed}, fold={fold}，"
                f"{reason}，用时 {format_duration(elapsed)}"
            )
            if not CONTINUE_ON_ERROR:
                break

    total_elapsed = time.time() - batch_start

    print()
    print("=" * 90)
    print("全部批量任务结束")
    print(f"总耗时：{format_duration(total_elapsed)}")
    print(f"成功：{len(succeeded)}")
    print(f"失败：{len(failed)}")
    print("=" * 90)

    if failed:
        print("\n失败任务：")
        for item in failed:
            print(
                f"[FAIL] dataset={item['dataset']}, "
                f"seed={item['seed']}, fold={item['fold']}，"
                f"原因：{item['reason']}"
            )
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())