# -*- coding: utf-8 -*-
"""Paired significance tests between two methods over the same shared splits.

Both CSVs should contain at least: dataset, seed, fold, and metric columns such as
`test_accuracy`, `test_f1_macro`, `test_roc_auc_macro_ovr`, `test_aupr_macro_ovr`.
"""
from __future__ import annotations

import argparse
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd
from scipy.stats import ttest_rel, wilcoxon


def cohen_d_paired(diff: np.ndarray) -> float:
    diff = diff[~np.isnan(diff)]
    if diff.size <= 1:
        return float("nan")
    sd = diff.std(ddof=1)
    if sd == 0:
        return float("inf") if diff.mean() > 0 else 0.0
    return float(diff.mean() / sd)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--method_a_csv", required=True, help="Usually baseline CSV, e.g. Node2Vec+MLP all metrics.")
    parser.add_argument("--method_b_csv", required=True, help="Usually your method CSV, e.g. RA-DDI all metrics.")
    parser.add_argument("--method_a_name", default="Node2Vec+MLP")
    parser.add_argument("--method_b_name", default="RA-DDI")
    parser.add_argument("--metrics", default="test_accuracy,test_f1_macro,test_roc_auc_macro_ovr,test_aupr_macro_ovr")
    parser.add_argument("--output_csv", required=True)
    args = parser.parse_args()

    a = pd.read_csv(args.method_a_csv)
    b = pd.read_csv(args.method_b_csv)
    merge_keys = ["dataset", "seed", "fold"]
    for k in merge_keys:
        if k not in a.columns or k not in b.columns:
            raise ValueError(f"Both CSVs must contain merge key {k!r}.")
    merged = a.merge(b, on=merge_keys, suffixes=("_a", "_b"), how="inner")
    if merged.empty:
        raise ValueError("No matched rows after merging on dataset/seed/fold. Check split IDs.")

    rows: List[Dict[str, object]] = []
    metrics = [m.strip() for m in args.metrics.split(",") if m.strip()]
    for dataset, g in merged.groupby("dataset", sort=True):
        for metric in metrics:
            ca, cb = f"{metric}_a", f"{metric}_b"
            if ca not in g.columns or cb not in g.columns:
                continue
            va = pd.to_numeric(g[ca], errors="coerce").to_numpy(dtype=float)
            vb = pd.to_numeric(g[cb], errors="coerce").to_numpy(dtype=float)
            mask = ~(np.isnan(va) | np.isnan(vb))
            va, vb = va[mask], vb[mask]
            if va.size < 2:
                continue
            diff = vb - va
            try:
                t_stat, t_p = ttest_rel(vb, va, nan_policy="omit")
            except Exception:
                t_stat, t_p = np.nan, np.nan
            try:
                w_stat, w_p = wilcoxon(vb, va, zero_method="wilcox", alternative="two-sided")
            except Exception:
                w_stat, w_p = np.nan, np.nan
            rows.append({
                "dataset": dataset,
                "metric": metric,
                "n_pairs": int(va.size),
                "method_a": args.method_a_name,
                "method_b": args.method_b_name,
                "mean_a": float(np.mean(va)),
                "std_a": float(np.std(va, ddof=1)),
                "mean_b": float(np.mean(vb)),
                "std_b": float(np.std(vb, ddof=1)),
                "mean_diff_b_minus_a": float(np.mean(diff)),
                "cohen_d_paired": cohen_d_paired(diff),
                "paired_t_p": float(t_p),
                "wilcoxon_p": float(w_p) if not np.isnan(w_p) else np.nan,
                "significant_0.05_t": bool(t_p < 0.05) if not np.isnan(t_p) else False,
                "significant_0.05_wilcoxon": bool(w_p < 0.05) if not np.isnan(w_p) else False,
            })
    out = pd.DataFrame(rows)
    out_path = Path(args.output_csv)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(out_path, index=False, encoding="utf-8-sig")
    print(f"Saved significance table: {out_path}")


if __name__ == "__main__":
    main()
