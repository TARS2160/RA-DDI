# -*- coding: utf-8 -*-
"""Summarize Node2Vec+MLP metrics over 15 shared splits."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Dict, List

import numpy as np
import pandas as pd


def flatten_metrics_json(path: Path) -> Dict[str, object]:
    with path.open("r", encoding="utf-8") as f:
        obj = json.load(f)
    row: Dict[str, object] = {
        "method": obj.get("method", "Node2Vec+MLP"),
        "dataset": obj.get("dataset"),
        "seed": obj.get("seed"),
        "fold": obj.get("fold"),
        "runtime_sec": obj.get("runtime_sec"),
        "train_size": obj.get("split_sizes", {}).get("train"),
        "val_size": obj.get("split_sizes", {}).get("val"),
        "test_size": obj.get("split_sizes", {}).get("test"),
        "train_graph_nodes": obj.get("train_graph", {}).get("nodes"),
        "train_graph_edges": obj.get("train_graph", {}).get("undirected_edges"),
        "missing_train": obj.get("missing_embedding_pair_rate", {}).get("train"),
        "missing_val": obj.get("missing_embedding_pair_rate", {}).get("val"),
        "missing_test": obj.get("missing_embedding_pair_rate", {}).get("test"),
        "best_epoch": obj.get("mlp", {}).get("best_epoch"),
    }
    for prefix in ["test", "val"]:
        for k, v in obj.get(f"{prefix}_metrics", {}).items():
            row[f"{prefix}_{k}"] = v
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results_dir", required=True)
    parser.add_argument("--output_dir", required=True)
    args = parser.parse_args()

    results_dir = Path(args.results_dir)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    metric_paths = sorted(results_dir.glob("*/seed_*_fold_*/metrics.json"))
    if not metric_paths:
        raise FileNotFoundError(f"No metrics.json found under {results_dir}")
    rows = [flatten_metrics_json(p) for p in metric_paths]
    df = pd.DataFrame(rows).sort_values(["dataset", "seed", "fold"])
    all_csv = output_dir / "node2vec_mlp_all_15fold_metrics.csv"
    df.to_csv(all_csv, index=False, encoding="utf-8-sig")

    metric_cols = [c for c in df.columns if c.startswith("test_") and pd.api.types.is_numeric_dtype(df[c])]
    summary_rows: List[Dict[str, object]] = []
    for dataset, g in df.groupby("dataset", sort=True):
        row: Dict[str, object] = {"method": "Node2Vec+MLP", "dataset": dataset, "n_splits": int(len(g))}
        for col in metric_cols:
            vals = pd.to_numeric(g[col], errors="coerce")
            row[f"{col}_mean"] = float(vals.mean())
            row[f"{col}_std"] = float(vals.std(ddof=1)) if vals.notna().sum() > 1 else float("nan")
        summary_rows.append(row)
    summary = pd.DataFrame(summary_rows)
    summary_csv = output_dir / "node2vec_mlp_summary_mean_std.csv"
    summary.to_csv(summary_csv, index=False, encoding="utf-8-sig")

    print(f"Saved per-split metrics: {all_csv}")
    print(f"Saved mean/std summary: {summary_csv}")


if __name__ == "__main__":
    main()
