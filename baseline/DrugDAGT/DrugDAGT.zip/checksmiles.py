# import pandas as pd
# from rdkit import Chem, RDLogger
#
# RDLogger.DisableLog("rdApp.*")
#
# path = "strict_data/drugbank_3class/drug_smiles_for_features.csv"
#
# df = pd.read_csv(path, dtype=str)
#
# print("columns:", list(df.columns))
# print("num rows:", len(df))
# print(df.head())
#
# # 自动寻找 smiles 列
# smiles_col = None
# for c in df.columns:
#     if c.lower() in ["smiles", "smile", "canonical_smiles", "drug_smiles"]:
#         smiles_col = c
#         break
#
# if smiles_col is None:
#     raise ValueError("没有自动找到 smiles 列，请看上面 columns，然后手动指定 smiles_col")
#
# print("using smiles column:", smiles_col)
#
# bad_rows = []
#
# for idx, row in df.iterrows():
#     smi = row[smiles_col]
#
#     if smi is None:
#         bad_rows.append((idx, "EMPTY", row.to_dict()))
#         continue
#
#     smi = str(smi).strip()
#
#     if smi == "" or smi.lower() in ["nan", "none", "null"]:
#         bad_rows.append((idx, "EMPTY_OR_NAN", row.to_dict()))
#         continue
#
#     mol = Chem.MolFromSmiles(smi)
#
#     if mol is None:
#         bad_rows.append((idx, smi, row.to_dict()))
#
# print("invalid smiles:", len(bad_rows))
#
# for item in bad_rows[:50]:
#     print("=" * 80)
#     print("csv line:", item[0] + 2)  # +2 是因为 pandas idx 从0开始，csv还有表头
#     print("bad smiles:", item[1])
#     print("row:", item[2])
#
# if bad_rows:
#     bad_df = pd.DataFrame([{
#         "pandas_index": x[0],
#         "csv_line": x[0] + 2,
#         "bad_smiles": x[1],
#         **x[2]
#     } for x in bad_rows])
#
#     bad_df.to_csv("strict_data/drugbank_3class/invalid_smiles_rows.csv", index=False, encoding="utf-8-sig")
#     print("Saved invalid rows to strict_data/drugbank_3class/invalid_smiles_rows.csv")


import pandas as pd
from rdkit import Chem, RDLogger

RDLogger.DisableLog("rdApp.*")

path = "strict_data/drugbank_3class/drug_smiles_for_features.csv"

df = pd.read_csv(path, dtype=str)

print("columns:", list(df.columns))
print("num rows:", len(df))
print(df.head())

# 自动寻找 smiles 列
smiles_col = None
for c in df.columns:
    if c.lower() in ["smiles", "smile", "canonical_smiles", "drug_smiles"]:
        smiles_col = c
        break

if smiles_col is None:
    raise ValueError("没有自动找到 smiles 列，请看上面 columns，然后手动指定 smiles_col")

print("using smiles column:", smiles_col)

bad_rows = []

for idx, row in df.iterrows():
    smi = row[smiles_col]

    if smi is None:
        bad_rows.append((idx, "EMPTY", row.to_dict()))
        continue

    smi = str(smi).strip()

    if smi == "" or smi.lower() in ["nan", "none", "null"]:
        bad_rows.append((idx, "EMPTY_OR_NAN", row.to_dict()))
        continue

    mol = Chem.MolFromSmiles(smi)

    if mol is None:
        bad_rows.append((idx, smi, row.to_dict()))

print("invalid smiles:", len(bad_rows))

for item in bad_rows[:50]:
    print("=" * 80)
    print("csv line:", item[0] + 2)  # +2 是因为 pandas idx 从0开始，csv还有表头
    print("bad smiles:", item[1])
    print("row:", item[2])

if bad_rows:
    bad_df = pd.DataFrame([{
        "pandas_index": x[0],
        "csv_line": x[0] + 2,
        "bad_smiles": x[1],
        **x[2]
    } for x in bad_rows])

    bad_df.to_csv("strict_data/drugbank_3class/invalid_smiles_rows.csv", index=False, encoding="utf-8-sig")
    print("Saved invalid rows to strict_data/drugbank_3class/invalid_smiles_rows.csv")