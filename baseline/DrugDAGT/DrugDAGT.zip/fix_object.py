import shutil
import numpy as np

path = "strict_data/pdd_graph_2class/features/rdkit_norm.npz"    #输入，输出
backup = "strict_data/pdd_graph_2class/features/rdkit_norm_object_backup.npz"

shutil.copyfile(path, backup)
print("backup saved to:", backup)

x = np.load(path, allow_pickle=True)["features"]

print("before shape:", x.shape)
print("before dtype:", x.dtype)

# object -> float32
if x.dtype == object:
    x = np.array(x.tolist(), dtype=np.float32)
else:
    x = np.array(x, dtype=np.float32)

# 保险：把 nan / inf 都替换为 0
x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)

print("after shape:", x.shape)
print("after dtype:", x.dtype)
print("nan count:", np.isnan(x).sum())

np.savez_compressed(path, features=x)
print("fixed saved to:", path)