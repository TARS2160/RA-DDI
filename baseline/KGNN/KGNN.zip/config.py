# -*- coding: utf-8 -*-
import os

RAW_DATA_DIR = os.getcwd() + '/raw_data'
PROCESSED_DATA_DIR = os.getcwd() + '/data'
LOG_DIR = os.getcwd() + '/log'
MODEL_SAVED_DIR = os.getcwd() + '/ckpt'
PREDICTION_DIR = os.getcwd() + '/predictions'
RESULT_DIR = os.getcwd() + '/result'
# Original KGNN raw-data locations. For strict reviewer setting, prefer passing
# --kg_file to run_shared_splits.py so each seed/fold uses a training-only or
# DDI-edge-masked KG.
KG_FILE = {
    'drugbank': os.path.join(RAW_DATA_DIR, 'drugbank', 'train2id.txt'),
    'kegg': os.path.join(RAW_DATA_DIR, 'kegg', 'train2id.txt'),
}
ENTITY2ID_FILE = {
    'drugbank': os.path.join(RAW_DATA_DIR, 'drugbank', 'entity2id.txt'),
    'kegg': os.path.join(RAW_DATA_DIR, 'kegg', 'entity2id.txt'),
}
EXAMPLE_FILE = {
    'drugbank': os.path.join(RAW_DATA_DIR, 'drugbank', 'approved_example.txt'),
    'kegg': os.path.join(RAW_DATA_DIR, 'kegg', 'approved_example.txt'),
}
SEPARATOR = {'drugbank': '\t', 'kegg': '\t'}
THRESHOLD = {'drugbank': 4, 'kegg': 4}
NEIGHBOR_SIZE = {'drugbank': 4, 'kegg': 4}

DRUG_VOCAB_TEMPLATE = '{dataset}_drug_vocab.pkl'
ENTITY_VOCAB_TEMPLATE = '{dataset}_entity_vocab.pkl'
RELATION_VOCAB_TEMPLATE = '{dataset}_relation_vocab.pkl'
ADJ_ENTITY_TEMPLATE = '{dataset}_adj_entity.npy'
ADJ_RELATION_TEMPLATE = '{dataset}_adj_relation.npy'
TRAIN_DATA_TEMPLATE = '{dataset}_train.npy'
DEV_DATA_TEMPLATE = '{dataset}_dev.npy'
TEST_DATA_TEMPLATE = '{dataset}_test.npy'
RESULT_LOG = {'drugbank': 'drugbank_result.txt', 'kegg': 'kegg_result.txt'}
PERFORMANCE_LOG = 'kgcn_performance.log'
DRUG_EXAMPLE = '{dataset}_examples.npy'


class ModelConfig(object):
    def __init__(self):
        self.neighbor_sample_size = 4
        self.embed_dim = 32
        self.n_depth = 2
        self.l2_weight = 1e-7
        self.lr = 2e-2
        self.batch_size = 65536
        self.aggregator_type = 'sum'
        self.n_epoch = 50
        self.optimizer = 'adam'

        self.drug_vocab_size = None
        self.entity_vocab_size = None
        self.relation_vocab_size = None
        self.adj_entity = None
        self.adj_relation = None

        # Shared-split experiments may be binary or multiclass.
        self.num_classes = 2
        self.class_names = None
        self.force_multiclass = False
        self.seed = None
        self.fold = None
        self.base_dataset = None
        self.prediction_dir = PREDICTION_DIR

        self.exp_name = None
        self.model_name = None

        self.checkpoint_dir = MODEL_SAVED_DIR
        # Use a metric that exists for both binary and multiclass settings.
        self.checkpoint_monitor = 'val_f1_macro'
        self.checkpoint_save_best_only = True
        self.checkpoint_save_weights_only = True
        self.checkpoint_save_weights_mode = 'max'
        self.checkpoint_verbose = 1

        self.early_stopping_monitor = 'val_f1_macro'
        self.early_stopping_mode = 'max'
        self.early_stopping_patience = 5
        self.early_stopping_verbose = 1
        self.dataset = 'drug'
        self.K_Fold = 1
        self.callbacks_to_add = None
        self.swa_start = 3
