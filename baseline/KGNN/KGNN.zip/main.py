# -*- coding: utf-8 -*-
import os
import gc
import time
import csv
import numpy as np
from keras import backend as K
from keras import optimizers

from utils import pickle_load, format_filename, write_log
from models import KGCN
from config import ModelConfig, PROCESSED_DATA_DIR, ENTITY_VOCAB_TEMPLATE, \
    RELATION_VOCAB_TEMPLATE, ADJ_ENTITY_TEMPLATE, ADJ_RELATION_TEMPLATE, LOG_DIR, \
    PERFORMANCE_LOG, DRUG_VOCAB_TEMPLATE, PREDICTION_DIR, RESULT_DIR

# Do not hard-code GPU 1. The runner sets CUDA_VISIBLE_DEVICES.
os.environ.setdefault('CUDA_VISIBLE_DEVICES', '0')


def get_optimizer(op_type, learning_rate):
    if op_type == 'sgd':
        return optimizers.SGD(learning_rate)
    elif op_type == 'rmsprop':
        return optimizers.RMSprop(learning_rate)
    elif op_type == 'adagrad':
        return optimizers.Adagrad(learning_rate)
    elif op_type == 'adadelta':
        return optimizers.Adadelta(learning_rate)
    elif op_type == 'adam':
        return optimizers.Adam(learning_rate, clipnorm=5)
    else:
        raise ValueError('Optimizer Not Understood: {}'.format(op_type))


def _ensure_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)


def _save_predictions(model, data, split_name, config, out_dir):
    _ensure_dir(out_dir)
    arr = np.asarray(data)
    x = [arr[:, :1], arr[:, 1:2]]
    y_true = arr[:, 2].astype(int)
    row_idx = arr[:, 3].astype(int) if arr.shape[1] >= 4 else np.arange(len(arr))
    y_prob = model.predict(x)
    y_prob = np.asarray(y_prob)

    if config.num_classes <= 2 and (y_prob.ndim == 1 or y_prob.shape[-1] == 1):
        score = y_prob.reshape(-1)
        y_pred = (score >= 0.5).astype(int)
        header = ['dataset', 'base_dataset', 'seed', 'fold', 'split', 'row_idx',
                  'drug1_id', 'drug2_id', 'y_true', 'y_pred', 'prob_1']
        rows = []
        for i in range(len(arr)):
            rows.append([config.dataset, config.base_dataset, config.seed, config.fold, split_name,
                         int(row_idx[i]), int(arr[i, 0]), int(arr[i, 1]), int(y_true[i]),
                         int(y_pred[i]), float(score[i])])
    else:
        y_pred = np.argmax(y_prob, axis=1).astype(int)
        header = ['dataset', 'base_dataset', 'seed', 'fold', 'split', 'row_idx',
                  'drug1_id', 'drug2_id', 'y_true', 'y_pred'] + \
                 ['prob_{}'.format(i) for i in range(config.num_classes)]
        rows = []
        for i in range(len(arr)):
            rows.append([config.dataset, config.base_dataset, config.seed, config.fold, split_name,
                         int(row_idx[i]), int(arr[i, 0]), int(arr[i, 1]), int(y_true[i]),
                         int(y_pred[i])] + [float(v) for v in y_prob[i, :config.num_classes]])

    out_file = os.path.join(out_dir, '{}_{}.csv'.format(config.exp_name, split_name))
    with open(out_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)
    print('Logging Info - Saved predictions:', out_file)



def _append_csv_row(csv_path, row, header):
    _ensure_dir(os.path.dirname(csv_path))
    need_header = (not os.path.exists(csv_path)) or os.path.getsize(csv_path) == 0

    with open(csv_path, 'a', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=header)
        if need_header:
            writer.writeheader()
        writer.writerow(row)


def _save_fold_result(config, train_log, train_size, valid_size, test_size):
    """
    保存每个 seed/fold 的最终结果。
    注意：这里保存的是 load_best_model() 后在 valid/test 上重新评估的指标。
    """
    result_root = RESULT_DIR
    dataset_dir = os.path.join(result_root, config.base_dataset)
    _ensure_dir(dataset_dir)

    row = {
        'method': 'KGNN',
        'dataset': config.base_dataset,
        'run_dataset': config.dataset,
        'seed': config.seed,
        'fold': config.fold,
        'num_classes': config.num_classes,
        'class_names': '|'.join([str(x) for x in config.class_names]) if config.class_names else '',
        'train_size': train_size,
        'valid_size': valid_size,
        'test_size': test_size,
        'selection_metric': train_log.get('selection_metric', 'val_f1_macro'),
        'train_time': train_log.get('train_time', ''),

        'valid_acc': train_log.get('dev_acc', ''),
        'valid_f1_macro': train_log.get('dev_f1_macro', ''),
        'valid_precision_macro': train_log.get('dev_precision_macro', ''),
        'valid_recall_macro': train_log.get('dev_recall_macro', ''),
        'valid_auroc_macro': train_log.get('dev_auroc_macro', ''),
        'valid_aupr_macro': train_log.get('dev_aupr_macro', ''),

        'test_acc': train_log.get('test_acc', ''),
        'test_f1_macro': train_log.get('test_f1_macro', ''),
        'test_precision_macro': train_log.get('test_precision_macro', ''),
        'test_recall_macro': train_log.get('test_recall_macro', ''),
        'test_auroc_macro': train_log.get('test_auroc_macro', ''),
        'test_aupr_macro': train_log.get('test_aupr_macro', ''),

        'batch_size': config.batch_size,
        'lr': config.lr,
        'aggregator_type': config.aggregator_type,
        'neighbor_sample_size': config.neighbor_sample_size,
        'embed_dim': config.embed_dim,
        'n_depth': config.n_depth,
        'exp_name': config.exp_name,
    }

    header = [
        'method',
        'dataset',
        'run_dataset',
        'seed',
        'fold',
        'num_classes',
        'class_names',
        'train_size',
        'valid_size',
        'test_size',
        'selection_metric',
        'train_time',

        'valid_acc',
        'valid_f1_macro',
        'valid_precision_macro',
        'valid_recall_macro',
        'valid_auroc_macro',
        'valid_aupr_macro',

        'test_acc',
        'test_f1_macro',
        'test_precision_macro',
        'test_recall_macro',
        'test_auroc_macro',
        'test_aupr_macro',

        'batch_size',
        'lr',
        'aggregator_type',
        'neighbor_sample_size',
        'embed_dim',
        'n_depth',
        'exp_name',
    ]

    # 1. 每一折单独一个结果文件
    fold_file = os.path.join(
        dataset_dir,
        '{}_seed_{}_fold_{}_result.csv'.format(
            config.base_dataset,
            config.seed,
            config.fold
        )
    )

    with open(fold_file, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        writer.writerow(row)

    print('Logging Info - Saved fold result:', fold_file)

    # 2. 每个数据集一个汇总文件，15 折会追加到这里
    dataset_all_file = os.path.join(
        dataset_dir,
        '{}_all_folds_results.csv'.format(config.base_dataset)
    )
    _append_csv_row(dataset_all_file, row, header)

    print('Logging Info - Appended dataset result:', dataset_all_file)

    # 3. KGNN 所有数据集的总汇总文件
    global_all_file = os.path.join(result_root, 'kgnn_all_results.csv')
    _append_csv_row(global_all_file, row, header)

    print('Logging Info - Appended global result:', global_all_file)


def train(train_d, dev_d, test_d, kfold, dataset, neighbor_sample_size, embed_dim, n_depth,
          l2_weight, lr, optimizer_type, batch_size, aggregator_type, n_epoch,
          callbacks_to_add=None, overwrite=True, num_classes=2, class_names=None,
          seed=None, fold=None, base_dataset=None, prediction_dir=PREDICTION_DIR,
          force_multiclass=False, save_predictions=False):
    config = ModelConfig()
    config.neighbor_sample_size = neighbor_sample_size
    config.embed_dim = embed_dim
    config.n_depth = n_depth
    config.l2_weight = l2_weight
    config.dataset = dataset
    config.base_dataset = base_dataset or dataset
    config.K_Fold = kfold
    config.seed = seed
    config.fold = fold if fold is not None else kfold
    config.lr = lr
    config.optimizer = get_optimizer(optimizer_type, lr)
    config.batch_size = batch_size
    config.aggregator_type = aggregator_type
    config.n_epoch = n_epoch
    config.callbacks_to_add = callbacks_to_add or ['modelcheckpoint', 'earlystopping']
    config.num_classes = int(num_classes)
    config.class_names = class_names
    config.force_multiclass = bool(force_multiclass)
    config.prediction_dir = prediction_dir
    config.checkpoint_monitor = 'val_f1_macro'
    config.early_stopping_monitor = 'val_f1_macro'

    config.drug_vocab_size = len(pickle_load(format_filename(PROCESSED_DATA_DIR,
                                                             DRUG_VOCAB_TEMPLATE,
                                                             dataset=dataset)))
    config.entity_vocab_size = len(pickle_load(format_filename(PROCESSED_DATA_DIR,
                                                               ENTITY_VOCAB_TEMPLATE,
                                                               dataset=dataset)))
    config.relation_vocab_size = len(pickle_load(format_filename(PROCESSED_DATA_DIR,
                                                                 RELATION_VOCAB_TEMPLATE,
                                                                 dataset=dataset)))
    config.adj_entity = np.load(format_filename(PROCESSED_DATA_DIR, ADJ_ENTITY_TEMPLATE,
                                                dataset=dataset))
    config.adj_relation = np.load(format_filename(PROCESSED_DATA_DIR, ADJ_RELATION_TEMPLATE,
                                                  dataset=dataset))

    config.exp_name = ('kgcn_{base}_run_{dataset}_seed_{seed}_fold_{fold}_neigh_{neigh}_'
                       'embed_{embed}_depth_{depth}_agg_{agg}_optimizer_{opt}_lr_{lr}_'
                       'batch_size_{bs}_epoch_{ep}_classes_{cls}').format(
        base=config.base_dataset, dataset=dataset, seed=config.seed, fold=config.fold,
        neigh=neighbor_sample_size, embed=embed_dim, depth=n_depth, agg=aggregator_type,
        opt=optimizer_type, lr=lr, bs=batch_size, ep=n_epoch, cls=config.num_classes)
    callback_str = '_' + '_'.join(config.callbacks_to_add)
    callback_str = callback_str.replace('_modelcheckpoint', '').replace('_earlystopping', '')
    config.exp_name += callback_str

    train_log = {'exp_name': config.exp_name, 'dataset': dataset, 'base_dataset': config.base_dataset,
                 'seed': seed, 'fold': config.fold, 'batch_size': batch_size,
                 'optimizer': optimizer_type, 'epoch': n_epoch, 'learning_rate': lr,
                 'num_classes': config.num_classes, 'class_names': class_names,
                 'aggregate_type': config.aggregator_type,
                 'selection_metric': 'val_f1_macro'}
    print('Logging Info - Experiment: %s' % config.exp_name)
    model_save_path = os.path.join(config.checkpoint_dir, '{}.hdf5'.format(config.exp_name))
    model = KGCN(config)

    train_data = np.asarray(train_d)
    valid_data = np.asarray(dev_d)
    test_data = np.asarray(test_d)
    if not os.path.exists(model_save_path) or overwrite:
        start_time = time.time()
        model.fit(x_train=[train_data[:, :1], train_data[:, 1:2]], y_train=train_data[:, 2:3],
                  x_valid=[valid_data[:, :1], valid_data[:, 1:2]], y_valid=valid_data[:, 2:3])
        elapsed_time = time.time() - start_time
        print('Logging Info - Training time: %s' % time.strftime('%H:%M:%S', time.gmtime(elapsed_time)))
        train_log['train_time'] = time.strftime('%H:%M:%S', time.gmtime(elapsed_time))

    print('Logging Info - Evaluate over valid data:')
    model.load_best_model()
    dev_metrics = model.score(x=[valid_data[:, :1], valid_data[:, 1:2]], y=valid_data[:, 2:3])
    for k, v in dev_metrics.items():
        train_log['dev_' + k] = v
    print('Logging Info - dev metrics:', dev_metrics)

    print('Logging Info - Evaluate over test data:')
    test_metrics = model.score(x=[test_data[:, :1], test_data[:, 1:2]], y=test_data[:, 2:3])
    for k, v in test_metrics.items():
        train_log['test_' + k] = v
    print('Logging Info - test metrics:', test_metrics)

    _save_fold_result(config, train_log, len(train_data), len(valid_data), len(test_data))

    if save_predictions:
        out_dir = os.path.join(prediction_dir, config.base_dataset)
        _save_predictions(model, train_data, 'train', config, out_dir)
        _save_predictions(model, valid_data, 'valid', config, out_dir)
        _save_predictions(model, test_data, 'test', config, out_dir)

    if 'swa' in config.callbacks_to_add:
        model.load_swa_model()
        swa_test_metrics = model.score(x=[test_data[:, :1], test_data[:, 1:2]], y=test_data[:, 2:3])
        for k, v in swa_test_metrics.items():
            train_log['swa_test_' + k] = v
        print('Logging Info - swa test metrics:', swa_test_metrics)

    train_log['timestamp'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    write_log(format_filename(LOG_DIR, PERFORMANCE_LOG), log=train_log, mode='a')
    del model
    gc.collect()
    K.clear_session()
    return train_log
